<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Skill Provider');

$userId = current_user_id();

$skillCount = $conn->prepare('SELECT COUNT(*) AS c FROM skills WHERE providerId = ?');
$skillCount->bind_param('i', $userId);
$skillCount->execute();
$skillCount = $skillCount->get_result()->fetch_assoc()['c'];

$pendingCount = $conn->prepare("SELECT COUNT(*) AS c FROM exchangeRequests WHERE providerId = ? AND status = 'Pending'");
$pendingCount->bind_param('i', $userId);
$pendingCount->execute();
$pendingCount = $pendingCount->get_result()->fetch_assoc()['c'];

$completedCount = $conn->prepare("SELECT COUNT(*) AS c FROM exchangeRequests WHERE providerId = ? AND status = 'Completed'");
$completedCount->bind_param('i', $userId);
$completedCount->execute();
$completedCount = $completedCount->get_result()->fetch_assoc()['c'];

$avgRating = $conn->prepare('SELECT AVG(rating) AS avg_rating FROM exchangeReviews WHERE revieweeId = ?');
$avgRating->bind_param('i', $userId);
$avgRating->execute();
$avgRating = $avgRating->get_result()->fetch_assoc()['avg_rating'];

$recentRequests = $conn->prepare(
    "SELECT er.id, er.status, er.requestedAt, s.name AS skillName, u.firstName, u.lastName
     FROM exchangeRequests er
     JOIN skills s ON er.skillId = s.id
     JOIN users u ON er.seekerId = u.id
     WHERE er.providerId = ?
     ORDER BY er.requestedAt DESC LIMIT 5"
);
$recentRequests->bind_param('i', $userId);
$recentRequests->execute();
$recentRequests = $recentRequests->get_result();

$pageTitle = 'Provider Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-banner">
    <img src="<?= h(profile_image_url($userId)) ?>" alt="Your profile picture">
    <div>
        <h1>Welcome back, <?= h($_SESSION['first_name']) ?> 👋</h1>
        <p>Here's a snapshot of your skill-sharing activity.</p>
    </div>
</div>

<div class="stat-grid">
    <div class="stat-card"><div class="num"><?= (int) $skillCount ?></div><div class="label">Skills Listed</div></div>
    <div class="stat-card"><div class="num"><?= (int) $pendingCount ?></div><div class="label">Pending Requests</div></div>
    <div class="stat-card"><div class="num"><?= (int) $completedCount ?></div><div class="label">Completed Exchanges</div></div>
    <div class="stat-card"><div class="num"><?= $avgRating ? number_format($avgRating, 1) : '—' ?></div><div class="label">Avg. Rating</div></div>
</div>

<div class="card">
    <h3>Quick Actions</h3>
    <a class="btn" href="<?= BASE_URL ?>/provider/add_skill.php">+ Add a Skill</a>
    <a class="btn btn-secondary" href="<?= BASE_URL ?>/provider/requests.php">Review Requests</a>
</div>

<div class="card">
    <h3>Recent Requests</h3>
    <?php if ($recentRequests->num_rows === 0): ?>
        <p style="color:var(--muted);">No exchange requests yet.</p>
    <?php else: ?>
        <table>
            <tr><th>Skill</th><th>Seeker</th><th>Status</th><th>Requested</th></tr>
            <?php while ($row = $recentRequests->fetch_assoc()): ?>
                <tr>
                    <td><?= h($row['skillName']) ?></td>
                    <td><?= h($row['firstName'] . ' ' . $row['lastName']) ?></td>
                    <td><span class="badge badge-<?= h($row['status']) ?>"><?= h($row['status']) ?></span></td>
                    <td><?= h(date('M j, Y', strtotime($row['requestedAt']))) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
