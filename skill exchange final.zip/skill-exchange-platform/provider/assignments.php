<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Skill Provider');

$userId = current_user_id();
$errors = [];
$allowedAssignmentTypes = [
    'application/pdf' => 'pdf',
    'application/msword' => 'doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
    'application/vnd.ms-excel' => 'xls',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
    'application/vnd.ms-powerpoint' => 'ppt',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
    'text/plain' => 'txt',
    'application/zip' => 'zip',
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    $requestId = (int) ($_POST['requestId'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $deadline = trim($_POST['deadline'] ?? '');

    if ($title === '' || strlen($title) > 150 || $deadline === '') {
        $errors[] = 'Please provide a title and deadline.';
    }

    $deadlineTimestamp = strtotime($deadline);
    if ($deadlineTimestamp === false || $deadlineTimestamp <= time()) {
        $errors[] = 'The deadline must be a future date and time.';
    }

    $requestStmt = $conn->prepare(
        'SELECT er.seekerId, u.firstName, u.lastName
         FROM exchangeRequests er
         JOIN users u ON u.id = er.seekerId
         WHERE er.id = ? AND er.providerId = ? AND er.status = \'Accepted\''
    );
    $requestStmt->bind_param('ii', $requestId, $userId);
    $requestStmt->execute();
    $request = $requestStmt->get_result()->fetch_assoc();
    $requestStmt->close();

    if (!$request) {
        $errors[] = 'Choose an accepted exchange request.';
    }

    $attachment = null;
    if (!empty($_FILES['attachment']['name'])) {
        $attachment = store_uploaded_file($_FILES['attachment'], 'assignments', $allowedAssignmentTypes);
        if (isset($attachment['error'])) {
            $errors[] = $attachment['error'];
        }
    }

    if (empty($errors)) {
        $deadlineForDatabase = date('Y-m-d H:i:s', $deadlineTimestamp);
        $attachmentName = $attachment['name'] ?? null;
        $attachmentPath = $attachment['path'] ?? null;
        $stmt = $conn->prepare(
            'INSERT INTO assignments (requestId, providerId, seekerId, title, description, deadline, fileName, filePath)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->bind_param(
            'iiisssss',
            $requestId,
            $userId,
            $request['seekerId'],
            $title,
            $description,
            $deadlineForDatabase,
            $attachmentName,
            $attachmentPath
        );
        $stmt->execute();
        $stmt->close();
        set_flash('Assignment sent to ' . $request['firstName'] . ' ' . $request['lastName'] . '.', 'success');
        header('Location: ' . BASE_URL . '/provider/assignments.php');
        exit;
    }
}

$eligibleStmt = $conn->prepare(
    "SELECT er.id AS requestId, u.firstName, u.lastName, s.name AS skillName
     FROM exchangeRequests er
     JOIN users u ON u.id = er.seekerId
     JOIN skills s ON s.id = er.skillId
     WHERE er.providerId = ? AND er.status = 'Accepted'
     ORDER BY u.firstName, u.lastName"
);
$eligibleStmt->bind_param('i', $userId);
$eligibleStmt->execute();
$eligibleRequests = $eligibleStmt->get_result();

$assignmentStmt = $conn->prepare(
    "SELECT a.id, a.title, a.description, a.deadline, a.fileName, a.filePath,
            u.firstName, u.lastName,
            (SELECT COUNT(*) FROM assignmentSubmissions sub WHERE sub.assignmentId = a.id) AS submissionCount,
            latest.fileName AS submissionFileName, latest.filePath AS submissionFilePath,
            latest.status AS submissionStatus, latest.submittedAt
     FROM assignments a
     JOIN users u ON u.id = a.seekerId
     LEFT JOIN (
         SELECT assignmentId, MAX(id) AS latestId
         FROM assignmentSubmissions
         GROUP BY assignmentId
     ) latestSubmission ON latestSubmission.assignmentId = a.id
     LEFT JOIN assignmentSubmissions latest ON latest.id = latestSubmission.latestId
     WHERE a.providerId = ?
     ORDER BY a.deadline ASC, a.createdAt DESC"
);
$assignmentStmt->bind_param('i', $userId);
$assignmentStmt->execute();
$assignments = $assignmentStmt->get_result();

$pageTitle = 'Assignments';
require __DIR__ . '/../includes/header.php';
?>
<h1>Assignments</h1>

<?php foreach ($errors as $error): ?>
    <div class="alert alert-error"><?= h($error) ?></div>
<?php endforeach; ?>

<div class="card">
    <h3>Give an Assignment</h3>
    <?php if ($eligibleRequests->num_rows === 0): ?>
        <p style="color:var(--muted);">Assignments are available after a seeker accepts an exchange request.</p>
    <?php else: ?>
        <form class="stacked" method="POST" action="<?= BASE_URL ?>/provider/assignments.php" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create">
            <label>Seeker and skill
                <select name="requestId" required>
                    <option value="">Choose an accepted seeker</option>
                    <?php while ($requestOption = $eligibleRequests->fetch_assoc()): ?>
                        <option value="<?= (int) $requestOption['requestId'] ?>" <?= ((int) ($_POST['requestId'] ?? 0) === (int) $requestOption['requestId']) ? 'selected' : '' ?>>
                            <?= h($requestOption['firstName'] . ' ' . $requestOption['lastName'] . ' - ' . $requestOption['skillName']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </label>
            <label>Title
                <input type="text" name="title" maxlength="150" value="<?= h($_POST['title'] ?? '') ?>" required>
            </label>
            <label>Instructions
                <textarea name="description" rows="5"><?= h($_POST['description'] ?? '') ?></textarea>
            </label>
            <label>Deadline
                <input type="datetime-local" name="deadline" value="<?= h($_POST['deadline'] ?? '') ?>" required>
            </label>
            <label>Attachment (optional)
                <input type="file" name="attachment" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.jpg,.jpeg,.png">
            </label>
            <p style="color:var(--muted);font-size:0.85rem;">Attachments must be 10 MB or smaller.</p>
            <button class="btn" type="submit">Send Assignment</button>
        </form>
    <?php endif; ?>
</div>

<div class="card">
    <h3>Assignments Sent</h3>
    <?php if ($assignments->num_rows === 0): ?>
        <p style="color:var(--muted);">No assignments sent yet.</p>
    <?php else: ?>
        <table>
            <tr><th>Assignment</th><th>Seeker</th><th>Deadline</th><th>Latest submission</th></tr>
            <?php while ($assignment = $assignments->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong><?= h($assignment['title']) ?></strong>
                        <?php if ($assignment['filePath']): ?>
                            <br><a href="<?= h(BASE_URL . '/' . $assignment['filePath']) ?>" target="_blank" rel="noopener">View attachment</a>
                        <?php endif; ?>
                    </td>
                    <td><?= h($assignment['firstName'] . ' ' . $assignment['lastName']) ?></td>
                    <td><?= h(date('M j, Y g:i A', strtotime($assignment['deadline']))) ?></td>
                    <td>
                        <?php if ($assignment['submissionFilePath']): ?>
                            <a href="<?= h(BASE_URL . '/' . $assignment['submissionFilePath']) ?>" target="_blank" rel="noopener"><?= h($assignment['submissionFileName']) ?></a>
                            <br><span style="color:var(--muted);font-size:0.85rem;"><?= h($assignment['submissionStatus']) ?> · <?= h(date('M j, Y g:i A', strtotime($assignment['submittedAt']))) ?></span>
                        <?php else: ?>
                            <span style="color:var(--muted);">No submission (<?= (int) $assignment['submissionCount'] ?> total)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php if ($assignment['description']): ?>
                    <tr><td colspan="4"><span style="color:var(--muted);">Instructions: <?= h($assignment['description']) ?></span></td></tr>
                <?php endif; ?>
            <?php endwhile; ?>
        </table>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
