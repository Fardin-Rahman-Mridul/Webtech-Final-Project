<?php
require_once __DIR__ . '/includes/auth.php';
require_login();

switch (current_role()) {
    case 'Skill Provider':
        header('Location: ' . BASE_URL . '/provider/dashboard.php');
        break;
    case 'Skill Seeker':
        header('Location: ' . BASE_URL . '/seeker/dashboard.php');
        break;
    case 'Admin':
        header('Location: ' . BASE_URL . '/admin/dashboard.php');
        break;
    default:
        header('Location: ' . BASE_URL . '/login.php');
}
exit;
