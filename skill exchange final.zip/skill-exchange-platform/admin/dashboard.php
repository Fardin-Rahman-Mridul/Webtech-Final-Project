<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Admin');

$userId = current_user_id();
$totalUsers = $conn->query('SELECT COUNT(*) AS c FROM users')->fetch_assoc()['c'];
$totalSkills = $conn->query('SELECT COUNT(*) AS c FROM skills')->fetch_assoc()['c'];
$totalRequests = $conn->query('SELECT COUNT(*) AS c FROM exchangeRequests')->fetch_assoc()['c'];
$completedExchanges = $conn->query("SELECT COUNT(*) AS c FROM exchangeRequests WHERE status = 'Completed'")->fetch_assoc()['c'];

$pageTitle = 'Admin Dashboard';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-banner">
    <img src="<?= h(profile_image_url($userId)) ?>" alt="Your profile picture">
    <div>
        <h1>Admin Dashboard</h1>
        <p>Platform-wide overview.</p>
    </div>
</div>

<div class="stat-grid">
    <div class="stat-card"><div class="num"><?= (int) $totalUsers ?></div><div class="label">Total Users</div></div>
    <div class="stat-card"><div class="num"><?= (int) $totalSkills ?></div><div class="label">Skills Listed</div></div>
    <div class="stat-card"><div class="num"><?= (int) $totalRequests ?></div><div class="label">Total Requests</div></div>
    <div class="stat-card"><div class="num"><?= (int) $completedExchanges ?></div><div class="label">Completed Exchanges</div></div>
</div>

<div class="card">
    <h3>Manage the Platform</h3>
    <a class="btn" href="<?= BASE_URL ?>/admin/users.php">Manage Users</a>
    <a class="btn btn-secondary" href="<?= BASE_URL ?>/admin/exchanges.php">Monitor Exchanges</a>
    <a class="btn btn-secondary" href="<?= BASE_URL ?>/admin/reports.php">View Reports</a>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
